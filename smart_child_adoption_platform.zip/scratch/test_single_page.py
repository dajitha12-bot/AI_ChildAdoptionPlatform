import sys
import os
import io

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from database.mongodb import db

def test_single_page_workflow():
    app = create_app()
    app.config['TESTING'] = True

    print("=== TESTING SINGLE PAGE VERIFIED AGENCIES & APPLICATION WORKFLOW ===")

    # Get demo user & trust from seeded MongoDB
    adopter_user = db.users.find_one({'email': 'user@example.com'})
    assert adopter_user is not None, "Demo adopter user not found"
    adopter_id = str(adopter_user['_id'])

    trust_user = db.users.find_one({'email': 'trust.abc@smartadoption.org'})
    assert trust_user is not None, "Demo trust user not found"
    trust_user_id = str(trust_user['_id'])

    client = app.test_client()
    with client.session_transaction() as sess:
        sess['user_id'] = adopter_id
        sess['user_email'] = 'user@example.com'
        sess['role'] = 'adopter'

    # 1. GET /adopter/trusts (Single Page)
    trusts_res = client.get('/adopter/trusts')
    assert trusts_res.status_code == 200, f"GET /adopter/trusts failed with status {trusts_res.status_code}"
    assert b"India-Wide Verified Adoption Agencies Directory" in trusts_res.data
    assert b"APPLY TO THIS AGENCY" in trusts_res.data
    print("[SUCCESS] GET /adopter/trusts returned Single Page successfully with search & agency cards.")

    # 2. Get active verified agency ID from MongoDB
    trust = db.trusts.find_one({'verified': True, 'status': {'$in': ['ACTIVE', 'Verified']}})
    assert trust is not None, "No active verified trust found in MongoDB"
    trust_id = str(trust['_id'])
    print(f"[SUCCESS] Found target verified agency: {trust.get('trust_name')} (ID: {trust_id})")

    # 3. POST /adopter/apply-agency (Submit Application on Same Page)
    form_data = {
        'trust_id': trust_id,
        'applicant_name': 'Test Adopter Applicant',
        'applicant_email': 'applicant.test@smartadoption.org',
        'phone': '9876543210',
        'date_of_birth': '1990-05-15',
        'address': '123 Test Street, Madurai',
        'state': 'Tamil Nadu',
        'district': 'Madurai',
        'city': 'Madurai',
        'language': 'Tamil',
        'family_status': 'Married',
        'family_members': '2',
        'occupation': 'Engineer',
        'preferences': 'Age 0-2 years preference',
        'remarks': 'Single page testing remark',
        'identity_proof': (io.BytesIO(b"%PDF-1.4 Mock Identity Content"), "identity_card.pdf"),
        'address_proof': (io.BytesIO(b"%PDF-1.4 Mock Address Content"), "address_doc.pdf")
    }

    apply_res = client.post('/adopter/apply-agency', data=form_data, content_type='multipart/form-data', follow_redirects=True)
    assert apply_res.status_code == 200, f"POST /adopter/apply-agency failed with status {apply_res.status_code}"
    assert b"APPLICATION SUBMITTED" in apply_res.data or b"submitted successfully" in apply_res.data
    print("[SUCCESS] Application submitted successfully via POST /adopter/apply-agency.")

    # 4. Verify database storage in adoption_applications & email_logs
    app_doc = db.adoption_applications.find_one({'applicant_email': 'applicant.test@smartadoption.org'})
    assert app_doc is not None, "Application document not found in adoption_applications"
    assert app_doc.get('status') == 'SUBMITTED'
    assert len(app_doc.get('documents', [])) == 2
    app_id = app_doc.get('application_id')
    print(f"[SUCCESS] Verified MongoDB record in adoption_applications: ID = {app_id}, Status = {app_doc.get('status')}")

    # Check email log in email_logs
    email_log = db.email_logs.find_one({'email': 'applicant.test@smartadoption.org'})
    assert email_log is not None, "Email log not found in email_logs"
    print(f"[SUCCESS] Verified SMTP email log entry: Subject = '{email_log.get('subject')}', Status = '{email_log.get('status')}'")

    # 5. Test Trust Status Update
    trust_client = app.test_client()
    with trust_client.session_transaction() as sess:
        sess['user_id'] = trust_user_id
        sess['user_email'] = 'trust.abc@smartadoption.org'
        sess['role'] = 'trust'

    req = db.adoption_requests.find_one({'request_id': app_id})
    if not req:
        req = db.adoption_requests.find_one({'adopter_id': app_doc['adopter_id']})

    req_id = str(req['_id'])
    update_res = trust_client.post(f'/trust/request/action/{req_id}', data={'action': 'status_update', 'new_status': 'UNDER_REVIEW'}, follow_redirects=True)
    assert update_res.status_code == 200

    # Verify status updated in adoption_applications
    updated_app = db.adoption_applications.find_one({'application_id': app_id})
    assert updated_app.get('status') == 'UNDER_REVIEW'
    print(f"[SUCCESS] Verified Trust status update to 'UNDER_REVIEW' in adoption_applications & journeys!")

    print("\nALL SINGLE PAGE VERIFIED AGENCIES WORKFLOW TESTS PASSED PERFECTLY!")

if __name__ == '__main__':
    test_single_page_workflow()
