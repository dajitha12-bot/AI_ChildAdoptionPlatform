import sys
import os

# Add parent directory to path so imports work
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from services.ai_agent import process_ai_query

def run_tests():
    test_questions = [
        "What is the adoption process?",
        "What is my current status?",
        "Which adoption agencies are in Madurai?",
        "How to adopt a child in India?",
        "தத்தெடுக்கும் வழிமுறை என்ன?"
    ]

    print("=== TESTING AI AGENT QUERY PROCESSOR ===")
    for q in test_questions:
        safe_q = q.encode('ascii', errors='replace').decode('ascii')
        print(f"\n--- QUESTION: '{safe_q}' ---")
        res = process_ai_query(user_id=None, question=q, target_lang='en')
        safe_resp = res['response'].encode('ascii', errors='replace').decode('ascii')
        print(f"RESPONSE:\n{safe_resp}")
        print(f"AGENCIES RETURNED COUNT: {len(res['agencies'])}")

if __name__ == "__main__":
    run_tests()
