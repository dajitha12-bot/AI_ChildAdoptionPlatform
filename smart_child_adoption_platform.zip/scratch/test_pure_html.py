import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from database.mongodb import db

def test_pure_html_app():
    app = create_app()
    app.config['TESTING'] = True

    print("=== TESTING PURE HTML & CSS APPLICATION (ZERO JAVASCRIPT) ===")

    adopter_user = db.users.find_one({'email': 'user@example.com'})
    assert adopter_user is not None, "Demo adopter user not found"
    adopter_id = str(adopter_user['_id'])

    client = app.test_client()
    with client.session_transaction() as sess:
        sess['user_id'] = adopter_id
        sess['user_email'] = 'user@example.com'
        sess['role'] = 'adopter'

    # 1. Test Login Page (Pure HTML Demo Buttons)
    login_page = client.get('/login')
    assert login_page.status_code == 200
    assert b"<script" not in login_page.data.lower()
    print("[SUCCESS] Login page has ZERO <script> tags!")

    # 2. Test Single Page Verified Agencies Directory
    trusts_page = client.get('/adopter/trusts')
    assert trusts_page.status_code == 200
    assert b"<script" not in trusts_page.data.lower()
    assert b"<details" in trusts_page.data.lower()
    print("[SUCCESS] Verified Agencies page uses native HTML <details>/<summary> and ZERO <script> tags!")

    # 3. Test AI Assistant Pure HTML Form POST
    ai_post = client.post('/adopter/ai-assistant', data={'question': 'What is the adoption process?'}, follow_redirects=True)
    assert ai_post.status_code == 200
    assert b"<script" not in ai_post.data.lower()
    assert b"Child Adoption Process in India" in ai_post.data
    print("[SUCCESS] AI Assistant pure HTML Form POST processed AI query and returned response with ZERO <script> tags!")

    print("\nALL PURE HTML & CSS TESTS PASSED PERFECTLY!")

if __name__ == '__main__':
    test_pure_html_app()
